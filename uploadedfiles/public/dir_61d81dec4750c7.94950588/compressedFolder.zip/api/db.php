<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "api";

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>