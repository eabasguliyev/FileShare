<?php
    require "db.php";

    $sql = "SELECT * FROM `week`";
    $result = mysqli_query($conn, $sql);
    $week = ['Heftenin gununu sec'];
    while($row = mysqli_fetch_assoc($result)) {
        $week[] = $row['name'];
    }
    $json = json_encode($week);
    print_r($json);

    mysqli_close($conn);
?>