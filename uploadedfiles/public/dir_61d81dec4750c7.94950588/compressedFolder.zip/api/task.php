<?php
    require "db.php";
    $status = isset($_REQUEST["status"]) ? $_REQUEST["status"] : 0;
    $day = isset($_REQUEST["day"]) ? $_REQUEST["day"] : 0;

    $sql = "SELECT task.name, task.desc, color.name 'color', week.name 'day', task.time, task.duration FROM `task`,`color`,`week` WHERE `status`=".$status." AND `day`=".$day." AND task.day=week.id AND task.color=color.id";
    $result = mysqli_query($conn, $sql);
    $task = [];
    while($row = mysqli_fetch_assoc($result)) {
        $task[] = $row;
    }
    $json = json_encode($task, JSON_UNESCAPED_UNICODE);
    print_r($json);

    mysqli_close($conn);
?>